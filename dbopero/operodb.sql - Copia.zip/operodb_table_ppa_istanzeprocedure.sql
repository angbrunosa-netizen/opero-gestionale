
-- --------------------------------------------------------

--
-- Struttura della tabella `ppa_istanzeprocedure`
--

CREATE TABLE `ppa_istanzeprocedure` (
  `ID` int(11) NOT NULL,
  `TargetEntityType` varchar(20) NOT NULL,
  `TargetEntityID` int(10) UNSIGNED NOT NULL,
  `ID_ProceduraDitta` int(10) UNSIGNED NOT NULL,
  `ID_UtenteCreatore` int(11) NOT NULL COMMENT 'L''utente che ha avviato la procedura',
  `DataInizio` datetime NOT NULL DEFAULT current_timestamp(),
  `DataPrevistaFine` date DEFAULT NULL,
  `DataConclusioneEffettiva` datetime DEFAULT NULL,
  `Stato` enum('In Corso','Completata','Annullata') NOT NULL DEFAULT 'In Corso',
  `Esito` text DEFAULT NULL COMMENT 'Note conclusive sulla procedura'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ppa_istanzeprocedure`
--

INSERT INTO `ppa_istanzeprocedure` (`ID`, `TargetEntityType`, `TargetEntityID`, `ID_ProceduraDitta`, `ID_UtenteCreatore`, `DataInizio`, `DataPrevistaFine`, `DataConclusioneEffettiva`, `Stato`, `Esito`) VALUES
(1, 'DITTA', 6, 2, 3, '2025-09-20 19:15:45', '2025-10-24', NULL, 'In Corso', NULL),
(5, 'DITTA', 7, 2, 3, '2025-09-20 19:15:45', '2025-08-30', NULL, 'In Corso', NULL),
(6, 'DITTA', 6, 1, 3, '2025-09-20 19:15:45', '2025-08-24', NULL, 'In Corso', NULL),
(7, 'DITTA', 6, 1, 3, '2025-09-20 19:15:45', '2025-08-30', NULL, 'In Corso', NULL),
(8, 'DITTA', 6, 2, 3, '2025-09-20 19:15:45', '2025-08-24', NULL, 'In Corso', NULL),
(9, 'DITTA', 6, 6, 3, '2025-09-20 19:15:45', '2025-11-29', NULL, 'In Corso', NULL),
(10, 'DITTA', 14, 2, 3, '2025-09-20 19:15:45', '2025-10-30', NULL, 'In Corso', NULL),
(12, 'DITTA', 12, 13, 3, '2025-09-23 20:16:56', '2025-09-26', NULL, 'In Corso', NULL),
(13, 'DITTA', 14, 13, 3, '2025-09-23 20:19:07', '2025-09-27', NULL, 'In Corso', NULL),
(14, 'UTENTE', 46, 7, 3, '2025-09-23 20:33:17', '2025-09-26', NULL, 'In Corso', NULL),
(15, 'UTENTE', 48, 13, 3, '2025-09-23 20:39:49', '2025-09-27', NULL, 'In Corso', NULL),
(16, 'DITTA', 12, 13, 3, '2025-09-23 20:40:25', '2025-10-05', NULL, 'In Corso', NULL),
(17, 'DITTA', 12, 13, 3, '2025-09-23 20:45:09', '2025-09-26', NULL, 'In Corso', NULL),
(18, 'DITTA', 16, 13, 3, '2025-09-24 14:49:47', '2025-09-25', NULL, 'In Corso', NULL),
(19, 'DITTA', 16, 7, 3, '2025-09-24 19:17:41', '2025-10-03', NULL, 'In Corso', NULL),
(20, 'DITTA', 16, 7, 3, '2025-09-24 19:20:35', '2025-09-26', NULL, 'In Corso', NULL),
(21, 'DITTA', 16, 14, 3, '2025-09-26 20:44:20', '2025-10-18', NULL, 'In Corso', NULL),
(22, 'UTENTE', 48, 14, 3, '2025-09-27 13:31:16', '2025-10-04', NULL, 'In Corso', NULL),
(23, 'DITTA', 14, 14, 3, '2025-10-01 20:30:41', '2025-10-25', NULL, 'In Corso', NULL);
