
-- --------------------------------------------------------

--
-- Struttura della tabella `liste_distribuzione`
--

CREATE TABLE `liste_distribuzione` (
  `id` int(11) NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `nome_lista` varchar(255) NOT NULL,
  `descrizione` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `liste_distribuzione`
--

INSERT INTO `liste_distribuzione` (`id`, `id_ditta`, `nome_lista`, `descrizione`) VALUES
(1, 1, 'Diretti', NULL),
(2, 1, 'Consulenti', NULL),
(3, 1, 'aziende', NULL);
