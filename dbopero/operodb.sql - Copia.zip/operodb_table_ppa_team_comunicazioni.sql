
-- --------------------------------------------------------

--
-- Struttura della tabella `ppa_team_comunicazioni`
--

CREATE TABLE `ppa_team_comunicazioni` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_team` int(11) NOT NULL,
  `id_utente_mittente` int(11) NOT NULL,
  `messaggio` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ppa_team_comunicazioni`
--

INSERT INTO `ppa_team_comunicazioni` (`id`, `id_team`, `id_utente_mittente`, `messaggio`, `created_at`) VALUES
(1, 7, 3, 'eee', '2025-09-24 15:39:07'),
(2, 7, 3, 'eee', '2025-09-24 15:39:24'),
(3, 7, 3, 'proveedo', '2025-09-24 16:12:17'),
(4, 7, 3, 'saluti\n', '2025-09-24 16:26:08'),
(5, 7, 3, 'ecco', '2025-09-24 16:51:34'),
(6, 10, 3, 'iiii', '2025-09-24 16:54:15'),
(7, 7, 3, 'kkk', '2025-09-24 17:36:22'),
(8, 5, 3, 'qqq', '2025-09-26 18:03:36'),
(9, 5, 3, 'salve\n', '2025-09-26 18:10:32'),
(10, 13, 3, 'mancano le misure specifiche', '2025-09-26 18:45:13'),
(11, 13, 3, 'il lavoro è pronto\n', '2025-09-27 10:09:10'),
(12, 14, 3, 'le misure del modello sono\n30 cm larghezza\n32 cm collo', '2025-09-27 11:32:45');
