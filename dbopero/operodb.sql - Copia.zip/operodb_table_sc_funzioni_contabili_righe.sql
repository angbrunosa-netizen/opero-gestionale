
-- --------------------------------------------------------

--
-- Struttura della tabella `sc_funzioni_contabili_righe`
--

CREATE TABLE `sc_funzioni_contabili_righe` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_funzione_contabile` int(10) UNSIGNED NOT NULL,
  `id_conto` int(11) NOT NULL,
  `tipo_movimento` enum('D','A') NOT NULL,
  `descrizione_riga_predefinita` varchar(255) DEFAULT NULL,
  `is_sottoconto_modificabile` tinyint(1) DEFAULT 1,
  `is_conto_ricerca` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `sc_funzioni_contabili_righe`
--

INSERT INTO `sc_funzioni_contabili_righe` (`id`, `id_funzione_contabile`, `id_conto`, `tipo_movimento`, `descrizione_riga_predefinita`, `is_sottoconto_modificabile`, `is_conto_ricerca`, `created_at`, `updated_at`) VALUES
(93, 9, 20, 'D', 'Costo per acquisto merci/servizi', 1, 0, '2025-09-20 15:15:45', '2025-09-20 15:15:45'),
(94, 9, 51, 'D', 'credito erario conto iva', 1, 0, '2025-09-20 15:15:45', '2025-09-20 15:15:45'),
(95, 9, 15, 'A', 'debito verso fornitore', 1, 1, '2025-09-20 15:15:45', '2025-09-20 15:15:45'),
(112, 11, 9, 'D', NULL, 1, 0, '2025-09-20 17:15:45', '2025-09-20 17:15:45'),
(113, 11, 10, 'D', NULL, 1, 0, '2025-09-20 17:15:45', '2025-09-20 17:15:45'),
(123, 13, 9, 'D', 'versamento contnati', 1, 0, '2025-09-20 17:15:45', '2025-09-20 17:15:45'),
(124, 13, 10, 'A', 'versamento in banca', 1, 0, '2025-09-20 17:15:45', '2025-09-20 17:15:45'),
(125, 12, 17, 'A', 'Iva a Debito', 1, 0, '2025-09-20 13:15:45', '2025-09-20 13:15:45'),
(126, 12, 25, 'A', 'ricavo vendita', 1, 0, '2025-09-20 13:15:45', '2025-09-20 13:15:45'),
(127, 12, 7, 'D', 'credito verso clienti', 1, 1, '2025-09-20 13:15:45', '2025-09-20 13:15:45'),
(128, 14, 6, 'D', '', 1, 1, '2025-09-26 18:34:32', '2025-09-26 18:34:32'),
(129, 14, 8, 'A', '', 1, 0, '2025-09-26 18:34:32', '2025-09-26 18:34:32');
