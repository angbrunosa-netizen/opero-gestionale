
-- --------------------------------------------------------

--
-- Struttura della tabella `mg_magazzini`
--

CREATE TABLE `mg_magazzini` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `codice` varchar(20) NOT NULL,
  `descrizione` varchar(100) NOT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `mg_magazzini`
--

INSERT INTO `mg_magazzini` (`id`, `id_ditta`, `codice`, `descrizione`, `note`, `created_at`, `updated_at`) VALUES
(1, 1, 'MAG_01', 'MAGAZZINO CENTRALE', 'MAGAZZINO CENTRALE', '2025-10-04 18:45:59', '2025-10-04 18:45:59');
