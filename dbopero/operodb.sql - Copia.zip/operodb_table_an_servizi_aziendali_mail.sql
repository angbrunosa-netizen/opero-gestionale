
-- --------------------------------------------------------

--
-- Struttura della tabella `an_servizi_aziendali_mail`
--

CREATE TABLE `an_servizi_aziendali_mail` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `nome_servizio` varchar(100) NOT NULL COMMENT 'Es: ''PPA_COMMUNICATION'', ''FATTURAZIONE''',
  `id_ditta_mail_account` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `an_servizi_aziendali_mail`
--

INSERT INTO `an_servizi_aziendali_mail` (`id`, `id_ditta`, `nome_servizio`, `id_ditta_mail_account`, `created_at`, `updated_at`) VALUES
(1, 1, 'PPA_COMUNICATION', 13, '2025-09-23 19:02:54', '2025-09-23 19:02:54');
