
-- --------------------------------------------------------

--
-- Struttura della tabella `ppa_azioni`
--

CREATE TABLE `ppa_azioni` (
  `ID` int(10) UNSIGNED NOT NULL,
  `ID_Processo` int(10) UNSIGNED NOT NULL,
  `NomeAzione` varchar(255) NOT NULL,
  `Descrizione` text DEFAULT NULL,
  `ID_RuoloDefault` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ppa_azioni`
--

INSERT INTO `ppa_azioni` (`ID`, `ID_Processo`, `NomeAzione`, `Descrizione`, `ID_RuoloDefault`) VALUES
(1, 4, 'Verifica strutture di vendita', 'Nel corso del primo appuntamento nella sede del cliente, è essenziale verificare lo stato dei punti vendita.  Verificare qualità assortimento - adeguatezza del personale - formazione del personale- qualità e completezza delle attrezzature - ', 3),
(22, 16, 'PROA', 'PRIMA', 3),
(25, 19, '2', '2', 2),
(27, 23, 'controllare lo stato', NULL, 3),
(28, 24, 'lavorazione', 'eseguire il lavoror', 3),
(29, 25, 'consegna al cliente', 'dimostrazione al cliente delle lavorazione eseguite\ne firma ricezione capo', 3),
(30, 26, 'Prepararsi per il ritiro', 'il cliente sarà avvisato', 4),
(31, 27, 'ritiro del capo', 'verificare il capo assieme al cliente', 3),
(32, 27, 'prendere le misure', 'le misure vanno prese con attenzione', 3),
(33, 28, 'messa a modello', 'raccogliere le informazione ed eseguire i lavori', 3),
(34, 29, 'chiamare il cliente', 'telefonare per il ritiro', 3),
(35, 29, 'incasso', 'prima della consegna incassare', 2);
