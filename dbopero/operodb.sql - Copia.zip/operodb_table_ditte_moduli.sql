
-- --------------------------------------------------------

--
-- Struttura della tabella `ditte_moduli`
--

CREATE TABLE `ditte_moduli` (
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `codice_modulo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ditte_moduli`
--

INSERT INTO `ditte_moduli` (`id_ditta`, `codice_modulo`) VALUES
(1, 10),
(1, 20),
(1, 30),
(1, 40),
(1, 50),
(1, 60),
(1, 70),
(1, 80),
(1, 90),
(1, 100),
(1, 110),
(2, 20),
(2, 30),
(2, 50),
(3, 10),
(3, 20),
(3, 30);
