
-- --------------------------------------------------------

--
-- Struttura della tabella `sc_registri_iva`
--

CREATE TABLE `sc_registri_iva` (
  `id` int(11) NOT NULL,
  `id_riga_registrazione` int(11) NOT NULL,
  `tipo_registro` enum('Acquisti','Vendite','Corrispettivi') NOT NULL,
  `data_documento` date NOT NULL,
  `numero_documento` varchar(50) NOT NULL,
  `id_anagrafica` int(11) DEFAULT NULL,
  `imponibile` decimal(15,2) NOT NULL,
  `aliquota_iva` decimal(5,2) NOT NULL,
  `importo_iva` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `sc_registri_iva`
--

INSERT INTO `sc_registri_iva` (`id`, `id_riga_registrazione`, `tipo_registro`, `data_documento`, `numero_documento`, `id_anagrafica`, `imponibile`, `aliquota_iva`, `importo_iva`) VALUES
(1, 18, 'Acquisti', '2025-09-09', '10', 15, 100.00, 22.00, 22.00),
(2, 21, 'Acquisti', '2025-09-09', '100', 15, 100.00, 10.00, 10.00),
(3, 76, 'Vendite', '2025-09-26', '15', 16, 1000.00, 22.00, 220.00),
(4, 77, 'Vendite', '2025-09-26', '15', 16, 200.00, 10.00, 20.00),
(5, 78, 'Vendite', '2025-09-26', '15', 16, 59.61, 4.00, 2.38);
