
-- --------------------------------------------------------

--
-- Struttura della tabella `ppa_team`
--

CREATE TABLE `ppa_team` (
  `ID` int(11) NOT NULL,
  `ID_IstanzaProcedura` int(11) NOT NULL,
  `NomeTeam` varchar(255) NOT NULL,
  `DataCreazione` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ppa_team`
--

INSERT INTO `ppa_team` (`ID`, `ID_IstanzaProcedura`, `NomeTeam`, `DataCreazione`) VALUES
(4, 5, 'Team Procedura #5 - 23/08/2025', '2025-09-20 17:15:45'),
(5, 6, 'Team Procedura #6 - 23/08/2025', '2025-09-20 17:15:45'),
(6, 7, 'Team Procedura #7 - 23/08/2025', '2025-09-20 17:15:45'),
(7, 8, 'Team Procedura #8 - 23/08/2025', '2025-09-20 17:15:45'),
(8, 9, 'Team Procedura #9 - 25/08/2025', '2025-09-20 17:15:45'),
(9, 10, 'Team Procedura #10 - 26/08/2025', '2025-09-20 17:15:45'),
(10, 18, 'Team per 23', '2025-09-24 12:49:47'),
(11, 19, 'Team per lavorazione_sartoria', '2025-09-24 17:17:41'),
(12, 20, 'Team per lavorazione_sartoria', '2025-09-24 17:20:35'),
(13, 21, 'Team per Lavorazioni_cliente', '2025-09-26 18:44:20'),
(14, 22, 'Team per Lavorazioni_cliente', '2025-09-27 11:31:16'),
(15, 23, 'Team per procedura 23', '2025-10-01 18:30:41');
