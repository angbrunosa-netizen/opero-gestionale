
-- --------------------------------------------------------

--
-- Struttura della tabella `email_inviate`
--

CREATE TABLE `email_inviate` (
  `id` int(11) NOT NULL,
  `id_ditta` int(10) UNSIGNED DEFAULT NULL,
  `id_utente_mittente` int(11) NOT NULL,
  `destinatari` text NOT NULL,
  `cc` text DEFAULT NULL,
  `bcc` text DEFAULT NULL,
  `oggetto` varchar(255) DEFAULT NULL,
  `corpo` longtext DEFAULT NULL,
  `data_invio` timestamp NOT NULL DEFAULT current_timestamp(),
  `aperta` tinyint(1) DEFAULT 0,
  `data_prima_apertura` timestamp NULL DEFAULT NULL,
  `tracking_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `email_inviate`
--

INSERT INTO `email_inviate` (`id`, `id_ditta`, `id_utente_mittente`, `destinatari`, `cc`, `bcc`, `oggetto`, `corpo`, `data_invio`, `aperta`, `data_prima_apertura`, `tracking_id`) VALUES
(1, NULL, 6, 'angbrunosa@gmai.com', NULL, NULL, 'ciao', NULL, '2025-09-20 17:15:45', 0, NULL, '974c346a-4882-4b6e-94a3-a1aa09163788'),
(74, NULL, 3, 'angbrunosa@gmail.com', NULL, NULL, 'prova da locale', '<p>saluti</p>', '2025-09-20 17:15:45', 0, NULL, '46bb71fe-e807-4df7-af08-8075341d8fde'),
(75, NULL, 3, 'angbrunosa@gmail.com', '', '', 'sss', '<p>ssss</p>', '2025-09-24 15:48:06', 0, NULL, 'f84f6674-4328-4dd4-8aa6-5b62c061c445'),
(76, NULL, 3, 'amerigo.celia@gmail.com', '', '', 'file fatture', '<p>in allegato quanto in oggetto	</p><p>saluti </p><p>Angelo</p><p><br></p>', '2025-09-26 09:56:08', 0, NULL, '2f87e111-76cc-4df8-9ffa-a44d26f722f2'),
(77, NULL, 3, 'mimmaforte@gmail.com', '', '', 'saluti', '<p>saluti</p>', '2025-09-26 18:53:58', 0, NULL, '646ba121-7ce8-4cc7-8973-ae2249e02397'),
(78, NULL, 3, 'angbrunosa@gmail.com', '', '', 'fff', '<p>ffff</p>', '2025-09-26 19:07:36', 0, NULL, '8d6a311e-b726-4cd0-b4cc-0429c63a9e4d'),
(79, NULL, 3, 'angbrunosa@gmail.com', '', '', 'prova', '<p>saluti</p>', '2025-09-28 08:48:46', 0, NULL, 'be7171bb-fb3d-4051-9cb2-65b26c953774'),
(80, 1, 3, 'opero@difam.it', NULL, NULL, 'Aggiornamento di Stato: Procedura \"23\"', '<p>Gentile Cliente,</p>\n            <p>le confermiamo che per le lavorazioni richieste le è stata assegnata la procedura \"23\".</p>\n            <p>In allegato trova il report di stato aggiornato ad oggi la data prevista di completamento è \"25/09/2025\".</p>\n            <p>Per qualsiasi domanda o chiarimento, non esiti a contattarci.</p>\n            <p>Cordiali Saluti,<br/>Opero Gestionale</p>', '2025-09-29 07:15:31', 0, NULL, '<ec360bf6-3eab-400f-ecaa-51e2a0f72955@difam.it>'),
(81, 1, 3, 'opero@difam.it', NULL, NULL, 'Aggiornamento di Stato: Procedura \"23\"', '<p>Gentile Cliente,</p>\n            <p>le confermiamo che per le lavorazioni richieste le è stata assegnata la procedura \"23\".</p>\n            <p>In allegato trova il report di stato aggiornato ad oggi la data prevista di completamento è \"25/09/2025\".</p>\n            <p>Per qualsiasi domanda o chiarimento, non esiti a contattarci.</p>\n            <p>Cordiali Saluti,<br/>Opero Gestionale</p>', '2025-09-29 07:15:31', 0, NULL, '9aeba883-cea0-44a0-b745-3582becd4af7'),
(82, 1, 3, 'opero@difam.it', NULL, NULL, 'Aggiornamento di Stato: Procedura \"Lavorazioni_cliente\"', '<p>Gentile Cliente,</p>\n            <p>le confermiamo che per le lavorazioni richieste le è stata assegnata la procedura \"Lavorazioni_cliente\".</p>\n            <p>In allegato trova il report di stato aggiornato ad oggi la data prevista di completamento è \"18/10/2025\".</p>\n            <p>Per qualsiasi domanda o chiarimento, non esiti a contattarci.</p>\n            <p>Cordiali Saluti,<br/>Opero Gestionale</p>', '2025-09-29 16:11:38', 0, NULL, '<c45069f7-553b-1413-6692-6f416dba6299@difam.it>'),
(83, 1, 3, 'opero@difam.it', NULL, NULL, 'Aggiornamento di Stato: Procedura \"Lavorazioni_cliente\"', '<p>Gentile Cliente,</p>\n            <p>le confermiamo che per le lavorazioni richieste le è stata assegnata la procedura \"Lavorazioni_cliente\".</p>\n            <p>In allegato trova il report di stato aggiornato ad oggi la data prevista di completamento è \"18/10/2025\".</p>\n            <p>Per qualsiasi domanda o chiarimento, non esiti a contattarci.</p>\n            <p>Cordiali Saluti,<br/>Opero Gestionale</p>', '2025-09-29 16:11:38', 0, NULL, '6c685921-2aa4-491c-9993-f6d156640eb2'),
(84, 1, 3, 'opero@difam.it', NULL, NULL, 'Aggiornamento di Stato: Procedura \"lavorazione_sartoria\"', '<p>Gentile Cliente,</p>\n            <p>le confermiamo che per le lavorazioni richieste le è stata assegnata la procedura \"lavorazione_sartoria\".</p>\n            <p>In allegato trova il report di stato aggiornato ad oggi la data prevista di completamento è \"03/10/2025\".</p>\n            <p>Per qualsiasi domanda o chiarimento, non esiti a contattarci.</p>\n            <p>Cordiali Saluti,<br/>Opero Gestionale</p>', '2025-10-01 18:31:19', 0, NULL, '<216b4eeb-dda9-5730-a19e-a176d7ab19d3@difam.it>'),
(85, 1, 3, 'opero@difam.it', NULL, NULL, 'Aggiornamento di Stato: Procedura \"lavorazione_sartoria\"', '<p>Gentile Cliente,</p>\n            <p>le confermiamo che per le lavorazioni richieste le è stata assegnata la procedura \"lavorazione_sartoria\".</p>\n            <p>In allegato trova il report di stato aggiornato ad oggi la data prevista di completamento è \"03/10/2025\".</p>\n            <p>Per qualsiasi domanda o chiarimento, non esiti a contattarci.</p>\n            <p>Cordiali Saluti,<br/>Opero Gestionale</p>', '2025-10-01 18:31:19', 0, NULL, '271e8e26-a9ad-43e5-9db6-1e5119b9e063');
