
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_ean`
--

CREATE TABLE `ct_ean` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `id_catalogo` int(10) UNSIGNED NOT NULL,
  `codice_ean` varchar(13) NOT NULL,
  `tipo_ean` enum('PRODOTTO','CONFEZIONE') NOT NULL,
  `tipo_ean_prodotto` enum('PEZZO','PESO','PREZZO') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ct_ean`
--

INSERT INTO `ct_ean` (`id`, `id_ditta`, `id_catalogo`, `codice_ean`, `tipo_ean`, `tipo_ean_prodotto`, `created_at`, `created_by`) VALUES
(1, 1, 1, '8006473903932', 'PRODOTTO', 'PEZZO', '2025-10-02 12:58:05', 3);
