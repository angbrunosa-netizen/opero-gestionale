
-- --------------------------------------------------------

--
-- Struttura della tabella `bs_categorie`
--

CREATE TABLE `bs_categorie` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `codice` varchar(50) DEFAULT NULL,
  `descrizione` varchar(255) DEFAULT NULL,
  `aliquota_ammortamento` decimal(5,2) DEFAULT NULL,
  `id_sottoconto_costi` int(11) DEFAULT NULL,
  `id_sottoconto_ammortamenti` int(11) DEFAULT NULL,
  `id_sottoconto_fondo` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `bs_categorie`
--

INSERT INTO `bs_categorie` (`id`, `id_ditta`, `codice`, `descrizione`, `aliquota_ammortamento`, `id_sottoconto_costi`, `id_sottoconto_ammortamenti`, `id_sottoconto_fondo`, `created_at`, `updated_at`) VALUES
(1, 1, 'IMM', 'Immobili', NULL, NULL, NULL, NULL, '2025-09-20 17:16:55', '2025-09-20 17:16:55'),
(2, 1, 'ARR', 'Arredamenti', NULL, NULL, NULL, NULL, '2025-09-20 17:16:55', '2025-09-20 17:16:55'),
(3, 1, 'ATT-IND', 'Attrezzatura Industriale', NULL, NULL, NULL, NULL, '2025-09-20 17:16:55', '2025-09-20 17:16:55'),
(4, 1, 'ATT-COM', 'Attrezzatura Commerciale', NULL, NULL, NULL, NULL, '2025-09-20 17:16:55', '2025-09-20 17:16:55'),
(5, 1, 'ATT-UFF', 'Attrezzatura Uffici', NULL, NULL, NULL, NULL, '2025-09-20 17:16:55', '2025-09-20 17:16:55'),
(6, 1, 'ELT', 'Elettronici', NULL, NULL, NULL, NULL, '2025-09-20 17:16:55', '2025-09-20 17:16:55'),
(7, 1, 'MAC-OP', 'Macchine Operatrici', NULL, NULL, NULL, NULL, '2025-09-20 17:16:55', '2025-09-20 17:16:55'),
(8, 1, 'OFF', 'Officina', NULL, NULL, NULL, NULL, '2025-09-20 17:16:55', '2025-09-20 17:16:55'),
(9, 1, 'MOB-REG', 'MOBILI REGISTRATI', NULL, NULL, NULL, NULL, '2025-09-21 10:54:30', '2025-09-21 10:54:30');
