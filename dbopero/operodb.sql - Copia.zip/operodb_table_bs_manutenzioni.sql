
-- --------------------------------------------------------

--
-- Struttura della tabella `bs_manutenzioni`
--

CREATE TABLE `bs_manutenzioni` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_bene` int(10) UNSIGNED NOT NULL,
  `data_intervento` date DEFAULT NULL,
  `tipo_intervento` enum('Ordinaria','Straordinaria','Programmata') DEFAULT NULL,
  `descrizione_intervento` text DEFAULT NULL,
  `id_fornitore_manutenzione` int(10) UNSIGNED DEFAULT NULL,
  `costo_intervento` decimal(15,2) DEFAULT NULL,
  `id_sottoconto_contabile` int(11) DEFAULT NULL,
  `documento_riferimento` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
