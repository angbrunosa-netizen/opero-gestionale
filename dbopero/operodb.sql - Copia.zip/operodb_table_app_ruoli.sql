
-- --------------------------------------------------------

--
-- Struttura della tabella `app_ruoli`
--

CREATE TABLE `app_ruoli` (
  `id` int(11) NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `codice_modulo` int(11) NOT NULL,
  `descrizione` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `app_ruoli`
--

INSERT INTO `app_ruoli` (`id`, `id_ditta`, `codice_modulo`, `descrizione`) VALUES
(2, 1, 10, 'Fatturista Junior'),
(1, 1, 10, 'Fatturista Senior');
