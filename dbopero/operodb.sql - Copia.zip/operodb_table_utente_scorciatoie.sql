
-- --------------------------------------------------------

--
-- Struttura della tabella `utente_scorciatoie`
--

CREATE TABLE `utente_scorciatoie` (
  `id_utente` int(11) NOT NULL,
  `id_funzione` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utente_scorciatoie`
--

INSERT INTO `utente_scorciatoie` (`id_utente`, `id_funzione`) VALUES
(3, 5),
(3, 26),
(3, 32),
(3, 34),
(3, 36),
(3, 38),
(3, 72),
(3, 84),
(4, 32);
