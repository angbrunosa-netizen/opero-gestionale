
-- --------------------------------------------------------

--
-- Struttura della tabella `ppa_procedureditta`
--

CREATE TABLE `ppa_procedureditta` (
  `ID` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `ID_ProceduraStandard` int(10) UNSIGNED NOT NULL,
  `NomePersonalizzato` varchar(255) NOT NULL,
  `TargetEntityTypeAllowed` varchar(20) NOT NULL DEFAULT 'DITTA',
  `Attiva` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ppa_procedureditta`
--

INSERT INTO `ppa_procedureditta` (`ID`, `id_ditta`, `ID_ProceduraStandard`, `NomePersonalizzato`, `TargetEntityTypeAllowed`, `Attiva`) VALUES
(1, 1, 1, 'Gruppo G%G spa ', 'DITTA', 1),
(2, 1, 2, 'Nuovi Clienti Top', 'DITTA', 1),
(3, 1, 3, 'prodotti venduti on line', 'DITTA', 1),
(4, 1, 1, 'Verifica Documenti', 'DITTA', 1),
(5, 1, 1, 'Tagliano Auto-FuoriGaranzia', 'DITTA', 1),
(6, 1, 1, 'Gestione Cliente Associato', 'DITTA', 1),
(7, 1, 2, 'lavorazione_sartoria', 'DITTA', 1),
(12, 1, 4, 'PRIMA', 'DITTA', 1),
(13, 1, 4, '23', 'DITTA', 1),
(14, 1, 4, 'Lavorazioni_cliente', 'UTENTE', 1);
