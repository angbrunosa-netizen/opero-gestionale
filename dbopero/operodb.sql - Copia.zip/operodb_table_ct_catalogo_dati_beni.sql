
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_catalogo_dati_beni`
--

CREATE TABLE `ct_catalogo_dati_beni` (
  `id_catalogo` int(10) UNSIGNED NOT NULL,
  `peso` decimal(10,3) DEFAULT NULL,
  `volume` decimal(10,3) DEFAULT NULL,
  `dimensioni` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
