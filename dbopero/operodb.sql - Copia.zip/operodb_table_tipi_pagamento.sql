
-- --------------------------------------------------------

--
-- Struttura della tabella `tipi_pagamento`
--

CREATE TABLE `tipi_pagamento` (
  `id` int(11) NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `codice` varchar(50) NOT NULL,
  `descrizione` varchar(255) NOT NULL,
  `gg_dilazione` int(11) DEFAULT 0 COMMENT 'Giorni di dilazione del pagamento.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `tipi_pagamento`
--

INSERT INTO `tipi_pagamento` (`id`, `id_ditta`, `codice`, `descrizione`, `gg_dilazione`) VALUES
(1, 3, '10', 'CONTANTI', 0),
(2, 3, '20', 'BONIFICO', 0),
(3, 3, '30', 'POS', 0),
(4, 3, '40', 'TITOLI', 0),
(5, 1, '10', 'CONTANTI', 0),
(6, 1, '20', 'BONIFICO', 1),
(7, 1, '30', 'POS', 1),
(8, 1, '40', 'TITOLI 30 gg', 30);
