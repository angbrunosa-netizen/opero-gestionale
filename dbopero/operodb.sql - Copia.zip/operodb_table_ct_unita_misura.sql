
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_unita_misura`
--

CREATE TABLE `ct_unita_misura` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `sigla_um` varchar(10) NOT NULL,
  `descrizione` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ct_unita_misura`
--

INSERT INTO `ct_unita_misura` (`id`, `id_ditta`, `sigla_um`, `descrizione`, `created_at`, `updated_at`) VALUES
(1, 1, 'PZ', 'PEZZI', '2025-09-30 14:45:41', '2025-09-30 14:45:41'),
(2, 1, 'CT', 'CARTONI', '2025-09-30 14:45:59', '2025-09-30 14:45:59'),
(3, 1, 'KG', 'Chilogrammi', '2025-09-30 17:43:33', '2025-09-30 17:43:33'),
(4, 1, 'LT', 'LITRO', '2025-09-30 17:43:45', '2025-09-30 17:43:45');
