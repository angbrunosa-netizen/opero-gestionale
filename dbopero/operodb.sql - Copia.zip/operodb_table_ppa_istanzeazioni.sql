
-- --------------------------------------------------------

--
-- Struttura della tabella `ppa_istanzeazioni`
--

CREATE TABLE `ppa_istanzeazioni` (
  `ID` int(11) NOT NULL,
  `ID_IstanzaProcedura` int(11) NOT NULL,
  `ID_Azione` int(10) UNSIGNED NOT NULL,
  `ID_UtenteAssegnato` int(11) NOT NULL,
  `ID_Stato` int(11) DEFAULT NULL,
  `DataScadenza` date DEFAULT NULL,
  `DataCompletamento` datetime DEFAULT NULL,
  `NoteSvolgimento` text DEFAULT NULL,
  `NoteParticolari` text DEFAULT NULL,
  `Note` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ppa_istanzeazioni`
--

INSERT INTO `ppa_istanzeazioni` (`ID`, `ID_IstanzaProcedura`, `ID_Azione`, `ID_UtenteAssegnato`, `ID_Stato`, `DataScadenza`, `DataCompletamento`, `NoteSvolgimento`, `NoteParticolari`, `Note`) VALUES
(1, 1, 1, 31, 1, NULL, NULL, NULL, NULL, NULL),
(51, 10, 8, 6, NULL, '2025-10-30', NULL, NULL, NULL, NULL),
(53, 12, 25, 3, 1, '2025-10-05', NULL, NULL, NULL, NULL),
(54, 13, 25, 3, 1, '2025-09-24', NULL, NULL, NULL, NULL),
(55, 14, 27, 6, 1, '2025-09-19', NULL, NULL, NULL, NULL),
(56, 14, 28, 31, 1, '2025-09-26', NULL, NULL, NULL, NULL),
(57, 14, 29, 6, 1, '2025-09-13', NULL, NULL, NULL, NULL),
(58, 14, 30, 48, 1, '2025-09-26', NULL, NULL, NULL, NULL),
(59, 15, 25, 3, 1, '2025-09-17', NULL, NULL, NULL, NULL),
(60, 16, 25, 3, 1, '2025-09-25', NULL, NULL, NULL, NULL),
(61, 17, 25, 3, 1, '2025-09-18', NULL, NULL, NULL, NULL),
(62, 18, 25, 3, 1, '2025-09-26', NULL, NULL, NULL, NULL),
(63, 19, 27, 6, 1, NULL, NULL, NULL, NULL, NULL),
(64, 19, 28, 31, 1, NULL, NULL, NULL, NULL, NULL),
(65, 19, 29, 6, 1, NULL, NULL, NULL, NULL, NULL),
(66, 19, 30, 48, 1, NULL, NULL, NULL, NULL, NULL),
(67, 20, 27, 6, 1, NULL, NULL, NULL, NULL, NULL),
(68, 20, 28, 6, 1, NULL, NULL, NULL, NULL, NULL),
(69, 20, 29, 31, 1, NULL, NULL, NULL, NULL, NULL),
(70, 20, 30, 48, 1, NULL, NULL, NULL, NULL, NULL),
(71, 21, 31, 31, 1, NULL, NULL, NULL, NULL, NULL),
(72, 21, 32, 31, 1, NULL, NULL, NULL, NULL, NULL),
(73, 21, 33, 6, 1, NULL, NULL, NULL, NULL, NULL),
(74, 21, 34, 31, 1, NULL, NULL, NULL, NULL, NULL),
(75, 21, 35, 3, 3, NULL, '2025-09-27 17:25:22', NULL, NULL, 'ho telefonato il clente che porterà solo soldi in contanti'),
(76, 22, 31, 6, 1, '2025-09-27', NULL, NULL, NULL, NULL),
(77, 22, 32, 31, 1, '2025-09-27', NULL, NULL, NULL, NULL),
(78, 22, 33, 6, 1, '2025-09-27', NULL, NULL, NULL, NULL),
(79, 22, 34, 31, 1, '2025-09-30', NULL, NULL, NULL, NULL),
(80, 22, 35, 3, 3, NULL, '2025-09-27 15:31:54', NULL, NULL, 'il campo è pronto '),
(81, 23, 31, 6, 1, '2025-10-16', NULL, NULL, 'rrr', NULL),
(82, 23, 32, 6, 1, NULL, NULL, NULL, NULL, NULL),
(83, 23, 33, 31, 1, NULL, NULL, NULL, NULL, NULL),
(84, 23, 34, 1, 1, '2025-10-03', NULL, NULL, NULL, NULL),
(85, 23, 35, 3, 1, NULL, NULL, NULL, NULL, NULL);
