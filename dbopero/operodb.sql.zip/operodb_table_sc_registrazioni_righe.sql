
-- --------------------------------------------------------

--
-- Struttura della tabella `sc_registrazioni_righe`
--

CREATE TABLE `sc_registrazioni_righe` (
  `id` int(11) NOT NULL,
  `id_testata` int(11) NOT NULL,
  `id_conto` int(11) NOT NULL,
  `descrizione_riga` varchar(255) DEFAULT NULL,
  `importo_dare` decimal(15,2) DEFAULT 0.00,
  `importo_avere` decimal(15,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `sc_registrazioni_righe`
--

INSERT INTO `sc_registrazioni_righe` (`id`, `id_testata`, `id_conto`, `descrizione_riga`, `importo_dare`, `importo_avere`) VALUES
(16, 6, 27, 'Fornitori Italia', 0.00, 122.00),
(72, 32, 17, 'Iva a Debito', 0.00, 1.00),
(73, 33, 54, 'Rif. doc 15 CAROFIGLIO SPA', 1502.00, 0.00),
(74, 33, 25, 'ricavo vendita', 0.00, 1259.61),
(75, 33, 17, 'Iva a Debito', 0.00, 242.39),
(76, 33, 17, 'Iva a Debito', 0.00, 220.00),
(77, 33, 17, 'Iva a Debito', 0.00, 20.00),
(78, 33, 17, 'Iva a Debito', 0.00, 2.38),
(79, 34, 54, 'Incasso/Pagamento Fatt. 15', 1502.00, 0.00),
(80, 34, 8, 'Incasso/Pagamento', 0.00, 1502.00);
