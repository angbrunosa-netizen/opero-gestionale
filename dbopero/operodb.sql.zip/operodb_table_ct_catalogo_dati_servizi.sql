
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_catalogo_dati_servizi`
--

CREATE TABLE `ct_catalogo_dati_servizi` (
  `id_catalogo` int(10) UNSIGNED NOT NULL,
  `durata_stimata` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
