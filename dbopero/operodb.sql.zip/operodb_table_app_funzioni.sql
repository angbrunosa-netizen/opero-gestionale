
-- --------------------------------------------------------

--
-- Struttura della tabella `app_funzioni`
--

CREATE TABLE `app_funzioni` (
  `id` int(11) NOT NULL,
  `codice_modulo` int(11) NOT NULL,
  `funzione` varchar(100) NOT NULL,
  `sotto_funzione` varchar(100) NOT NULL,
  `descrizione` text DEFAULT NULL,
  `livello_richiesto` int(11) DEFAULT 50
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `app_funzioni`
--

INSERT INTO `app_funzioni` (`id`, `codice_modulo`, `funzione`, `sotto_funzione`, `descrizione`, `livello_richiesto`) VALUES
(1, 10, 'Ciclo_Attivo', 'Fatturazione_Crea', NULL, 80),
(2, 10, 'Ciclo_Attivo', 'Fatturazione_Vedi', NULL, 50);
