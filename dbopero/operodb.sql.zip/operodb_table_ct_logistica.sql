
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_logistica`
--

CREATE TABLE `ct_logistica` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `id_catalogo` int(10) UNSIGNED NOT NULL,
  `peso_lordo_pz` decimal(10,3) DEFAULT 0.000,
  `volume_pz` decimal(10,6) DEFAULT 0.000000,
  `h_pz` decimal(10,2) DEFAULT 0.00,
  `l_pz` decimal(10,2) DEFAULT 0.00,
  `p_pz` decimal(10,2) DEFAULT 0.00,
  `s_im` int(11) DEFAULT 0,
  `pezzi_per_collo` int(11) DEFAULT 0,
  `colli_per_strato` int(11) DEFAULT 0,
  `strati_per_pallet` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ct_logistica`
--

INSERT INTO `ct_logistica` (`id`, `id_ditta`, `id_catalogo`, `peso_lordo_pz`, `volume_pz`, `h_pz`, `l_pz`, `p_pz`, `s_im`, `pezzi_per_collo`, `colli_per_strato`, `strati_per_pallet`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 0.006, 0.000004, NULL, NULL, NULL, 2, 3, NULL, NULL, '2025-10-04 15:27:08', '2025-10-04 15:27:08');
