
-- --------------------------------------------------------

--
-- Struttura della tabella `mg_causali_movimento`
--

CREATE TABLE `mg_causali_movimento` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `codice` varchar(20) NOT NULL,
  `descrizione` varchar(100) NOT NULL,
  `tipo` enum('carico','scarico') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `mg_causali_movimento`
--

INSERT INTO `mg_causali_movimento` (`id`, `id_ditta`, `codice`, `descrizione`, `tipo`, `created_at`, `updated_at`) VALUES
(1, 1, 'DDT', 'DOCUMENTO DI  TRASPORTO VENDITA', 'scarico', '2025-10-04 18:46:46', '2025-10-04 18:47:18'),
(2, 1, 'B_AC', 'BOLLA CONSEGNA ACQUISTI', 'carico', '2025-10-04 18:47:13', '2025-10-04 18:47:13'),
(3, 1, 'RETT_INV+', 'RETTIFICA INVENTARIALE POSITIVA', 'carico', '2025-10-04 18:47:48', '2025-10-04 18:47:48'),
(4, 1, 'RETT_INV-', 'RETTIFICA INVENTARIALE NEGAT', 'carico', '2025-10-04 18:48:18', '2025-10-04 18:48:18');
