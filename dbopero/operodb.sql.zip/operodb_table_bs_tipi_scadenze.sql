
-- --------------------------------------------------------

--
-- Struttura della tabella `bs_tipi_scadenze`
--

CREATE TABLE `bs_tipi_scadenze` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `codice` varchar(50) NOT NULL,
  `descrizione` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `bs_tipi_scadenze`
--

INSERT INTO `bs_tipi_scadenze` (`id`, `id_ditta`, `codice`, `descrizione`, `created_at`, `updated_at`) VALUES
(1, 1, '', 'SCADENZE MECCANICHE', '2025-10-04 15:52:30', '2025-10-04 15:52:30');
