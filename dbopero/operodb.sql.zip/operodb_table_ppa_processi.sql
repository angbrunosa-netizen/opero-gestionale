
-- --------------------------------------------------------

--
-- Struttura della tabella `ppa_processi`
--

CREATE TABLE `ppa_processi` (
  `ID` int(10) UNSIGNED NOT NULL,
  `ID_ProceduraDitta` int(10) UNSIGNED NOT NULL,
  `NomeProcesso` varchar(255) NOT NULL,
  `OrdineSequenziale` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ppa_processi`
--

INSERT INTO `ppa_processi` (`ID`, `ID_ProceduraDitta`, `NomeProcesso`, `OrdineSequenziale`) VALUES
(1, 3, 'Stabilire contatto con Cliente - Email- Telefonico .', 0),
(2, 3, 'Verifica Consegna', 0),
(3, 3, 'Contattare il Cliente per soluzione', 0),
(4, 2, 'Appuntamento con la Direzione ', 0),
(5, 2, 'Gestione Cliente dedicata per i primi 3 mesi', 0),
(6, 2, 'Valutazione stato ', 0),
(8, 1, 'prova 1', 0),
(9, 6, 'Gestione Assortimento', 0),
(10, 6, 'Gestione Promozioni', 0),
(11, 6, 'Amministrative', 0),
(12, 4, 'raccolta dati documeti', 0),
(16, 12, 'PRIMA', 0),
(19, 13, '2e', 0),
(23, 7, 'Ricezione_Verifica_Capo', 0),
(24, 7, 'lavorazione', 0),
(25, 7, 'consegna-capo', 0),
(26, 7, 'ritiro capo', 0),
(27, 14, 'Consegna materiale', 0),
(28, 14, 'lavorazioni', 0),
(29, 14, 'consegna del prodotto finio', 0);
