
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_codici_fornitore`
--

CREATE TABLE `ct_codici_fornitore` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `id_catalogo` int(10) UNSIGNED NOT NULL,
  `id_anagrafica_fornitore` int(10) UNSIGNED DEFAULT NULL,
  `codice_articolo_fornitore` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `tipo_codice` enum('ST','OCC') NOT NULL DEFAULT 'OCC'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ct_codici_fornitore`
--

INSERT INTO `ct_codici_fornitore` (`id`, `id_ditta`, `id_catalogo`, `id_anagrafica_fornitore`, `codice_articolo_fornitore`, `created_at`, `updated_at`, `created_by`, `tipo_codice`) VALUES
(1, 1, 1, 16, '10', '2025-10-02 14:16:22', '2025-10-02 14:16:22', 3, 'OCC'),
(2, 1, 1, 12, 'trio', '2025-10-03 07:23:11', '2025-10-03 07:23:11', 3, 'ST');
