
-- --------------------------------------------------------

--
-- Struttura della tabella `bs_scadenze`
--

CREATE TABLE `bs_scadenze` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_bene` int(10) UNSIGNED NOT NULL,
  `id_tipo_scadenza` int(10) UNSIGNED DEFAULT NULL,
  `descrizione` text DEFAULT NULL,
  `data_scadenza` date DEFAULT NULL,
  `giorni_preavviso` int(11) DEFAULT 7,
  `id_fornitore_associato` int(10) UNSIGNED DEFAULT NULL,
  `importo_previsto` decimal(15,2) DEFAULT NULL,
  `stato` enum('Pianificata','Completata','Annullata') DEFAULT 'Pianificata',
  `data_completamento` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `bs_scadenze`
--

INSERT INTO `bs_scadenze` (`id`, `id_bene`, `id_tipo_scadenza`, `descrizione`, `data_scadenza`, `giorni_preavviso`, `id_fornitore_associato`, `importo_previsto`, `stato`, `data_completamento`, `note`, `created_at`, `updated_at`) VALUES
(2, 1, 1, NULL, '2025-10-05', 7, NULL, 25.00, 'Pianificata', NULL, 'CAMBIARE VENTOLA OGNI ANNO', '2025-10-04 15:53:07', '2025-10-04 15:53:07');
