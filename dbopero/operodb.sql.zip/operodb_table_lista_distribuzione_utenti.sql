
-- --------------------------------------------------------

--
-- Struttura della tabella `lista_distribuzione_utenti`
--

CREATE TABLE `lista_distribuzione_utenti` (
  `id_lista` int(11) NOT NULL,
  `id_utente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `lista_distribuzione_utenti`
--

INSERT INTO `lista_distribuzione_utenti` (`id_lista`, `id_utente`) VALUES
(1, 1),
(1, 3),
(1, 6),
(1, 9),
(2, 1),
(2, 3),
(2, 6),
(2, 9),
(2, 31),
(2, 43),
(3, 1),
(3, 3);
