
-- --------------------------------------------------------

--
-- Struttura della tabella `lista_distribuzione_ditte`
--

CREATE TABLE `lista_distribuzione_ditte` (
  `id_lista` int(11) NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `lista_distribuzione_ditte`
--

INSERT INTO `lista_distribuzione_ditte` (`id_lista`, `id_ditta`) VALUES
(3, 6),
(3, 7),
(3, 12);
