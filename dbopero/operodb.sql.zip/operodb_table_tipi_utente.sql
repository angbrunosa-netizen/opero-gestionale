
-- --------------------------------------------------------

--
-- Struttura della tabella `tipi_utente`
--

CREATE TABLE `tipi_utente` (
  `Codice` int(11) NOT NULL,
  `Descrizione` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `tipi_utente`
--

INSERT INTO `tipi_utente` (`Codice`, `Descrizione`) VALUES
(1, 'Utente_Interno'),
(2, 'Utente_Esterno');
