
-- --------------------------------------------------------

--
-- Struttura della tabella `sc_partite_aperte`
--

CREATE TABLE `sc_partite_aperte` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta_anagrafica` int(10) UNSIGNED NOT NULL,
  `data_scadenza` date NOT NULL,
  `importo` decimal(15,2) NOT NULL,
  `stato` enum('APERTA','CHIUSA','INSOLUTA') DEFAULT 'APERTA',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_registrazione` date NOT NULL,
  `id_registrazione_testata` int(11) NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `id_anagrafica` int(10) UNSIGNED DEFAULT NULL,
  `numero_documento` varchar(50) DEFAULT NULL,
  `data_documento` date DEFAULT NULL,
  `id_sottoconto` int(10) UNSIGNED DEFAULT NULL,
  `tipo_movimento` enum('Apertura_Credito','Apertura_Debito','Chiusura','Chiusura_Credito','Chiusura_Debito','Storno_Apertura_Credito','Storno_Apertura_Debito') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `sc_partite_aperte`
--

INSERT INTO `sc_partite_aperte` (`id`, `id_ditta_anagrafica`, `data_scadenza`, `importo`, `stato`, `created_at`, `updated_at`, `data_registrazione`, `id_registrazione_testata`, `id_ditta`, `id_anagrafica`, `numero_documento`, `data_documento`, `id_sottoconto`, `tipo_movimento`) VALUES
(1, 15, '2025-09-11', 122.00, 'APERTA', '2025-09-20 17:15:45', '2025-09-20 17:15:45', '2025-09-09', 6, 0, NULL, NULL, NULL, NULL, 'Apertura_Credito'),
(17, 14, '2025-11-25', 11.00, 'APERTA', '2025-09-20 17:15:45', '2025-09-20 17:15:45', '2025-09-13', 32, 0, NULL, NULL, NULL, NULL, 'Apertura_Credito'),
(18, 16, '2025-10-26', 1502.00, 'CHIUSA', '2025-09-26 18:30:55', '2025-09-26 18:30:55', '2025-09-26', 33, 1, 16, '15', '2025-09-26', 54, 'Apertura_Credito'),
(19, 16, '2025-09-26', 1502.00, 'CHIUSA', '2025-09-26 18:35:01', '2025-09-26 18:35:01', '2025-09-26', 34, 1, NULL, '', '0000-00-00', 54, 'Chiusura_Credito');
