
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_categorie`
--

CREATE TABLE `ct_categorie` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `nome_categoria` varchar(100) NOT NULL,
  `descrizione` text DEFAULT NULL,
  `codice_categoria` varchar(255) DEFAULT NULL,
  `progressivo` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_padre` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ct_categorie`
--

INSERT INTO `ct_categorie` (`id`, `id_ditta`, `nome_categoria`, `descrizione`, `codice_categoria`, `progressivo`, `created_at`, `updated_at`, `id_padre`) VALUES
(15, 1, 'MERCI', 'PRODOTTI FISICI DI MAGAZZINO ', NULL, NULL, '2025-09-29 19:00:38', '2025-09-29 19:00:38', NULL),
(16, 1, 'FOOD', 'PRODOTTI ALIMENTARI', NULL, NULL, '2025-09-29 19:00:53', '2025-09-29 19:00:53', 15),
(17, 1, 'NO FOOD', 'NON ALIMENTARI', NULL, NULL, '2025-09-29 19:01:14', '2025-09-29 19:01:14', 15),
(18, 1, 'DEPERIBILI', 'ALIMENTARI DEPERIBILI', NULL, NULL, '2025-09-29 19:01:34', '2025-09-29 19:01:34', 16),
(19, 1, 'SERVIZI', 'SERVIZI AZIENDALI', NULL, NULL, '2025-09-29 19:07:17', '2025-09-29 19:07:17', NULL),
(20, 1, 'LAVORAZIONI', 'LAVORAZIONI ESEGUITE', NULL, NULL, '2025-09-29 19:07:35', '2025-09-29 19:07:35', NULL),
(21, 1, 'LIQUIDI', 'PRODOTTI LIQUIDI', NULL, NULL, '2025-09-30 17:18:23', '2025-09-30 17:18:23', 16),
(22, 1, 'DISPENSA', 'PRODOTTI DIPENSA', NULL, NULL, '2025-09-30 17:18:50', '2025-09-30 17:18:50', 16),
(24, 1, 'SURGELATI', 'PRODOTTI SURGELATI', NULL, NULL, '2025-09-30 17:19:44', '2025-09-30 17:19:44', 18),
(25, 1, 'FRESCHI', 'PRODOTTI FRESCHI', NULL, NULL, '2025-09-30 17:20:38', '2025-09-30 17:20:38', 18),
(26, 1, 'IGIENE CASA', 'IGIENE CASA', NULL, NULL, '2025-09-30 17:21:11', '2025-09-30 17:21:11', 17),
(29, 1, 'IGIENE PERSONA', 'IGIENE PERSONA', NULL, NULL, '2025-09-30 17:21:51', '2025-09-30 17:21:51', 17);
