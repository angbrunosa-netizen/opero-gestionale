
-- --------------------------------------------------------

--
-- Struttura della tabella `mg_movimenti_lotti`
--

CREATE TABLE `mg_movimenti_lotti` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_movimento` int(10) UNSIGNED NOT NULL,
  `id_lotto` int(10) UNSIGNED NOT NULL,
  `quantita` decimal(12,4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
