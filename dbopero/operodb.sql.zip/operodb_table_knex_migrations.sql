
-- --------------------------------------------------------

--
-- Struttura della tabella `knex_migrations`
--

CREATE TABLE `knex_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `batch` int(11) DEFAULT NULL,
  `migration_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `knex_migrations`
--

INSERT INTO `knex_migrations` (`id`, `name`, `batch`, `migration_time`) VALUES
(1, '20250906125707_initial_schema.js', 1, '2025-09-06 14:38:10'),
(2, '20250906160546_crea_tabelle_sc_funzioni_contabili.js', 2, '2025-09-08 06:57:20'),
(3, '20250907181507_aggiungi_tipi_funzione_contabile.js', 3, '2025-09-08 07:04:10'),
(5, '20250907215521_crea_tabella_funzioni_collegate.js', 4, '2025-09-08 07:32:39'),
(6, '20250907221322_migliora_gestione_automatismi.js', 4, '2025-09-08 07:32:39'),
(7, '20250908072347_crea_tabella_sc_funzioni_collegate.js', 4, '2025-09-08 07:32:39'),
(8, '20250908105000_rollback_tipi_funzione_errati.js', 5, '2025-09-08 08:54:53'),
(9, '20250908105301_funzionietipi.js', 5, '2025-09-08 08:54:53'),
(10, '20250909155018_aggiungi_data_registrazione_a_sc_partite_aperte.js', 6, '2025-09-09 15:53:05'),
(11, '20250909155025_aggiungi_id_testata_a_sc_partite_aperte.js', 7, '2025-09-09 16:00:37'),
(12, '20250909155045_AGGIUNGITABELLERELAZIONIDITTAEMODIFICADITTA.js', NULL, '2025-09-12 18:25:14'),
(13, '20250906145045_cancellatabelleosolete.js', 8, '2025-09-12 19:25:33'),
(14, '20250906145050_cancellatabelleosolete2.js', 9, '2025-09-13 07:29:16'),
(15, '20250906145051_cancellatabelleosoletecontiemastri.js', 10, '2025-09-13 08:34:03'),
(16, '20250906155045_fixmodificaunsignedditta.js', 11, '2025-09-13 09:34:49'),
(17, '20251309100045_ripristinatabbelaivacontabili.js', 12, '2025-09-13 09:56:35'),
(19, '20251309110052_modifichetabellaregitestatanumproti.js', 14, '2025-09-13 12:46:19'),
(20, '20250913121500_aggiorna_sc_registrazioni_testata.js', 15, '2025-09-13 12:56:09'),
(21, '20250913151500_TABELLAPROGRESSIVI_AN_DITTA.js', 16, '2025-09-13 12:59:38'),
(22, '20250913161500_modificatipifunzione.js', 17, '2025-09-13 17:12:21'),
(23, '20250916100000_add_fields_to_sc_partite_aperte.js', 18, '2025-09-16 08:18:01'),
(24, '20251609170052_tipo_scrittconta.js', 19, '2025-09-16 16:15:48'),
(25, '20250917105500_add_data_ult_to_an_progressivi.js', 20, '2025-09-17 08:57:01'),
(26, '20250917150000_add_camporicercarihecontabili.js', 21, '2025-09-17 12:38:19'),
(27, '20251709160052_tipo_scrittconta.js', 22, '2025-09-17 13:01:50'),
(28, '20251809160052_TABELLAUTENTIMAIL.js', 23, '2025-09-19 07:33:01'),
(32, '20250920180000_crea_modulo_beni_strumentali.js', 25, '2025-09-20 14:13:54'),
(33, '20250920193000_add_sottoconto_costo_to_bs_beni.js', 26, '2025-09-20 17:31:30'),
(34, '20250921191000_crea_tipi_scadenza.js', 27, '2025-09-22 07:32:55'),
(35, '20250921211000_modificanometabtipiscade.js', 27, '2025-09-22 07:32:55'),
(36, '20250921211000_modificanoscadenzede.js', NULL, '2025-09-22 07:34:42'),
(39, '202502209160052_PPA_1.js', 28, '2025-09-22 08:17:46'),
(40, '202502209160052_PPA_2.js', 28, '2025-09-22 08:17:46'),
(41, '202502209160052_PPA_3.js', 28, '2025-09-22 08:17:46'),
(42, '2025021309100045_creatbellamailservizi.js', 29, '2025-09-23 19:00:59'),
(43, '2025024309100045_creatbellateamcomunicai.js', 30, '2025-09-24 13:56:24'),
(44, '20250273161500_inserimentocaponote.js', 31, '2025-09-27 09:21:06'),
(45, '20250274309100045_implementamail.js', 32, '2025-09-27 17:08:45'),
(46, '20250290309100045_TABELLECATALOGOEMAG1.js', 33, '2025-09-29 10:18:25'),
(47, '20251809230052_TABELLLETTIMAIL.js', 34, '2025-09-29 17:23:25'),
(48, '20251809235052_TABELLLETTIMigraL.js', 35, '2025-09-29 17:28:48'),
(49, '20252009160052_TABELLAUTENTIMAIL.js', 36, '2025-09-29 17:29:06'),
(50, '202529091848_modificacategorie.js', 36, '2025-09-29 17:29:06'),
(52, '20250930190000_crea_tabella_stati_entita.js', 38, '2025-09-30 15:31:36'),
(53, '20250930190200_add_stato_to_ct_catalogo.js', 39, '2025-09-30 15:35:44'),
(54, '20251001090000_rename_prezzo_base_in_ct_catalogo.js', 40, '2025-10-01 07:05:53'),
(55, '20251001090100_crea_tabella_ct_listini.js', 41, '2025-10-01 07:07:00'),
(58, '20250917150000_creazionetabellectean.js', 42, '2025-10-02 09:40:51'),
(59, '20251001180000_crea_tabella_ct_listini_avanzata.js', 42, '2025-10-02 09:40:51'),
(60, '20251001200200_rename_ricarico_fields_in_ct_listini.js', 42, '2025-10-02 09:40:51'),
(61, '20250210309100045_ct_codici_fornitore1.js', 43, '2025-10-02 13:19:59'),
(62, '20251002164000_add_tipo_codice_to_ct_codici_fornitore.js', 44, '2025-10-02 14:37:57'),
(63, '202510040309100045_TABELLECATALOGOLOG.js', 45, '2025-10-04 14:47:56'),
(64, '20251004191500_create_magazzino_tables.js', 46, '2025-10-04 17:32:28'),
(65, '202529091948_modificacategorie2.js', 46, '2025-10-04 17:32:28'),
(66, '20251005__create_mg_giacenze_table.js', 47, '2025-10-05 17:06:00'),
(67, '20251005__create_diff-pag.js', 48, '2025-10-05 19:13:53'),
(68, '20251005__create_tbva.js', 49, '2025-10-05 19:14:32'),
(70, '202507102247_creatab_doc.js', 51, '2025-10-07 20:50:04'),
(71, '202507102247_creatab_doc.js', NULL, '2025-10-07 20:52:33');
