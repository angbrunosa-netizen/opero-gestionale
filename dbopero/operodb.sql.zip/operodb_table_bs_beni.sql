
-- --------------------------------------------------------

--
-- Struttura della tabella `bs_beni`
--

CREATE TABLE `bs_beni` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `id_categoria` int(10) UNSIGNED NOT NULL,
  `codice_bene` varchar(100) NOT NULL,
  `descrizione` text DEFAULT NULL,
  `matricola` varchar(255) DEFAULT NULL,
  `url_foto` varchar(500) DEFAULT NULL,
  `data_acquisto` date DEFAULT NULL,
  `valore_acquisto` decimal(15,2) DEFAULT NULL,
  `id_sottoconto_costo` int(11) DEFAULT NULL,
  `id_sottoconto_cespite` int(11) DEFAULT NULL,
  `id_fornitore` int(10) UNSIGNED DEFAULT NULL,
  `riferimento_fattura` varchar(255) DEFAULT NULL,
  `stato` enum('In uso','In manutenzione','Dismesso','In magazzino') DEFAULT 'In magazzino',
  `ubicazione` varchar(255) DEFAULT NULL,
  `data_dismissione` date DEFAULT NULL,
  `valore_dismissione` decimal(15,2) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `bs_beni`
--

INSERT INTO `bs_beni` (`id`, `id_ditta`, `id_categoria`, `codice_bene`, `descrizione`, `matricola`, `url_foto`, `data_acquisto`, `valore_acquisto`, `id_sottoconto_costo`, `id_sottoconto_cespite`, `id_fornitore`, `riferimento_fattura`, `stato`, `ubicazione`, `data_dismissione`, `valore_dismissione`, `note`, `created_at`, `updated_at`) VALUES
(1, 1, 6, 'PC_OLIVETI-M24', 'PC OLIVETTI M 24', 'PCIT000', 'www.fk', '1980-10-10', 7500.00, 22, 4, 8, '150', 'In uso', 'UFFICIO REPERTI', NULL, NULL, 'il pc presenta segni di usura, tastiera scolorita', '2025-09-20 18:14:20', '2025-09-20 18:14:20');
