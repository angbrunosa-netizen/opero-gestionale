
-- --------------------------------------------------------

--
-- Struttura della tabella `mg_movimenti`
--

CREATE TABLE `mg_movimenti` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `id_magazzino` int(10) UNSIGNED NOT NULL,
  `id_catalogo` int(10) UNSIGNED NOT NULL,
  `id_causale` int(10) UNSIGNED NOT NULL,
  `id_utente` int(11) DEFAULT NULL,
  `data_movimento` timestamp NOT NULL DEFAULT current_timestamp(),
  `quantita` decimal(12,4) NOT NULL,
  `valore_unitario` decimal(12,4) DEFAULT NULL,
  `riferimento_doc` varchar(100) DEFAULT NULL,
  `id_riferimento_doc` int(10) UNSIGNED DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
