
-- --------------------------------------------------------

--
-- Struttura della tabella `bs_costi`
--

CREATE TABLE `bs_costi` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_bene` int(10) UNSIGNED NOT NULL,
  `data_costo` date DEFAULT NULL,
  `descrizione_costo` varchar(255) DEFAULT NULL,
  `importo` decimal(15,2) DEFAULT NULL,
  `id_sottoconto_contabile` int(11) DEFAULT NULL,
  `documento_riferimento` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
