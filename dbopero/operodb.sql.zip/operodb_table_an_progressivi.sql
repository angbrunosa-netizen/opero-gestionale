
-- --------------------------------------------------------

--
-- Struttura della tabella `an_progressivi`
--

CREATE TABLE `an_progressivi` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_ditta` int(10) UNSIGNED NOT NULL,
  `codice_progressivo` varchar(50) NOT NULL,
  `descrizione` varchar(255) DEFAULT NULL,
  `serie` varchar(10) DEFAULT NULL,
  `ultimo_numero` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data_ult` date DEFAULT NULL,
  `formato` varchar(100) DEFAULT NULL COMMENT 'Es. {ANNO}/{SERIE}/{NUMERO}'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `an_progressivi`
--

INSERT INTO `an_progressivi` (`id`, `id_ditta`, `codice_progressivo`, `descrizione`, `serie`, `ultimo_numero`, `data_ult`, `formato`) VALUES
(1, 1, 'PROT_CONT', 'Protocollo Registrazioni Contabili', NULL, 19, NULL, NULL);
