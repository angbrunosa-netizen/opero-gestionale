
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_stati_entita`
--

CREATE TABLE `ct_stati_entita` (
  `id` int(10) UNSIGNED NOT NULL,
  `codice` varchar(10) NOT NULL,
  `descrizione` varchar(100) NOT NULL,
  `visibilita` varchar(255) DEFAULT NULL COMMENT 'Indica contesti di visibilità specifici, es. ECOMMERCE, ADMIN',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ct_stati_entita`
--

INSERT INTO `ct_stati_entita` (`id`, `codice`, `descrizione`, `visibilita`, `created_at`, `updated_at`) VALUES
(1, 'ATT', 'ATTIVO', '', '2025-09-30 15:33:08', '2025-09-30 15:33:08'),
(2, 'REV', 'IN REVISIONE', 'ADMIN', '2025-09-30 15:34:03', '2025-09-30 15:34:03'),
(3, 'OBS', 'OBSOLETO', 'ADMIN', '2025-09-30 15:34:25', '2025-09-30 15:34:25'),
(4, 'DEL', 'ARCHIVIATO- (ELIMINATO)', 'ADMIN', '2025-09-30 15:35:01', '2025-09-30 15:35:01');
