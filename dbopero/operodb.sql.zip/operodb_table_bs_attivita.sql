
-- --------------------------------------------------------

--
-- Struttura della tabella `bs_attivita`
--

CREATE TABLE `bs_attivita` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_bene` int(10) UNSIGNED NOT NULL,
  `id_utente_utilizzatore` int(11) DEFAULT NULL,
  `data_inizio` datetime DEFAULT NULL,
  `data_fine` datetime DEFAULT NULL,
  `ore_utilizzo` decimal(10,2) DEFAULT NULL,
  `unita_prodotte` decimal(15,2) DEFAULT NULL,
  `valore_contatore` decimal(15,2) DEFAULT NULL,
  `descrizione_attivita` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
