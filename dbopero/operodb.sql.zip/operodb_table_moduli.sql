
-- --------------------------------------------------------

--
-- Struttura della tabella `moduli`
--

CREATE TABLE `moduli` (
  `codice` int(11) NOT NULL,
  `descrizione` varchar(255) NOT NULL,
  `chiave_componente` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `moduli`
--

INSERT INTO `moduli` (`codice`, `descrizione`, `chiave_componente`) VALUES
(10, 'Amministrazione', 'AMMINISTRAZIONE'),
(20, 'Contabilità Smart', 'CONT_SMART'),
(30, 'Pannello Admin', 'ADMIN_PANEL'),
(40, 'Posta', 'MAIL'),
(50, 'Rubrica', 'RUBRICA'),
(60, 'Gestione Finanza', 'FIN_SMART'),
(70, 'BS SMART', 'BSSMART'),
(80, 'SISTEMA PPA', 'PPA SIS'),
(90, 'CATALOGO', 'CT_VIEW'),
(100, 'MAGAZZINO', 'MG_VIEW'),
(110, 'VENDITE', 'VA_CLIENTI_VIEW');
