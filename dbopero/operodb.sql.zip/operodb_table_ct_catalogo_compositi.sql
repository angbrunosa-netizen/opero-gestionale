
-- --------------------------------------------------------

--
-- Struttura della tabella `ct_catalogo_compositi`
--

CREATE TABLE `ct_catalogo_compositi` (
  `id_catalogo_padre` int(10) UNSIGNED NOT NULL,
  `id_catalogo_componente` int(10) UNSIGNED NOT NULL,
  `quantita_componente` decimal(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
