
-- --------------------------------------------------------

--
-- Struttura della tabella `utente_mail_accounts`
--

CREATE TABLE `utente_mail_accounts` (
  `id_utente` int(11) NOT NULL,
  `id_mail_account` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utente_mail_accounts`
--

INSERT INTO `utente_mail_accounts` (`id_utente`, `id_mail_account`, `created_at`, `updated_at`) VALUES
(3, 11, '2025-09-20 07:35:41', '2025-09-20 07:35:41'),
(3, 13, '2025-09-20 07:35:41', '2025-09-20 07:35:41');
